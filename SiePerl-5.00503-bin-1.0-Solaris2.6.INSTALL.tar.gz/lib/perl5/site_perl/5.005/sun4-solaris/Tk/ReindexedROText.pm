use strict;
package Tk::ReindexedROText;

use vars qw($VERSION);
$VERSION = '3.002'; # $Id: //depot/Tk8/TextList/ReindexedROText.pm#2 $

use Tk::Reindex qw(Tk::ROText);
use base qw(Tk::Reindex Tk::ROText);
Construct Tk::Widget 'ReindexedROText';

1;


