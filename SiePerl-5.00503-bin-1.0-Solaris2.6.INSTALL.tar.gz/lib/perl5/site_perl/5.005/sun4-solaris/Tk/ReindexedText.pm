use strict;
package Tk::ReindexedText;

use vars qw($VERSION);
$VERSION = '3.002'; # $Id: //depot/Tk8/TextList/ReindexedText.pm#2 $

use Tk::Reindex qw(Tk::Text);
use base qw(Tk::Reindex Tk::Text);
Construct Tk::Widget 'ReindexedText';

1;


