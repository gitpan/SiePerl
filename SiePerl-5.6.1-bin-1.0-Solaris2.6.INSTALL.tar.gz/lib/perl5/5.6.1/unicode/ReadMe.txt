August 30, 2000

This directory contains the first update release for Unicode 3.0.

This release consists of corrections and additions to the
Unicode Character Database for the Unicode Standard, 
Version 3.0.1.

Detailed documentation of the files constituting the
Unicode Character Database (contributory data files for
the standard itself) can now be found in
UnicodeCharacterDatabase.html.

