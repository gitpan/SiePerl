return <<'END';
0d00	0d7f
1200	135a
END
